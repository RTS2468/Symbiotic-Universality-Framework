UF White Paper (v1.3.35) — LaTeX Edition
Date: 2025-08-06

Files:
- UF_WhitePaper_v1_3_35.tex

Compile (choose one):
  pdflatex -interaction=nonstopmode UF_WhitePaper_v1_3_35.tex
  lualatex -interaction=nonstopmode UF_WhitePaper_v1_3_35.tex
  xelatex  -interaction=nonstopmode UF_WhitePaper_v1_3_35.tex
