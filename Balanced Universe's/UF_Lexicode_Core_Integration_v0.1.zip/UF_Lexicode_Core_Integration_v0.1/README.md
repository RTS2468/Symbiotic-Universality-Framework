# UF Lexicode ↔ Verification Core Integration (v0.1)

Date: 2025-08-06

This bundle wires **Lexicode** concept words to the **Verification Core v1.1**:
- Parses lexicode `mnemo` strings (e.g., `RI-HC01-C80-F05-EG05-B-O-RV`).
- Sets **caps/thresholds** accordingly (harm caps, fairness KL cap, evidence gap cap).
- Runs the core and applies a stricter **consent threshold** if `Cxx` is present.

## Files
- `verification_core_v1_1.py` — the core (copied from your workspace).
- `lexicode.py` + `codebook.json` — encoder/decoder (optional; gateway parses mnemo directly).
- `lexicode_gateway.py` — the wiring.

## Quick demo
```bash
python lexicode_gateway.py demo
```
It uses: `RI-HC01-C80-F05-EG05-B-O-RV # 9B2C` and prints the config + verification report.

## Extending
- Add `HCxx` to change high-stakes harm cap; `med/low` derived as 5x/10x.
- Add `Fxx` for fairness KL cap; `EGxx` for claim–evidence gap.
- Add `Cxx` to require a minimum consent for all subjects (simple v0.1 rule).
- Future versions can add tokens to flip risk modes (`Hcvar`, `Hdro`) or causal checks (`CA`).
