#!/usr/bin/env python3
"""
lexicode_gateway.py — Wire Lexicode to UF Verification Core v1.1

Usage (demo):
  python lexicode_gateway.py demo

Programmatic use:
  from lexicode_gateway import run_with_lexicode, parse_mnemo
"""
import json, re
from dataclasses import asdict
from datetime import datetime

# Local imports (bundled)
import verification_core_v1_1 as VC

MNEMO_PARAM_MAP = {
    "HC": ("harm_cap_high", lambda v: float(v)/100.0),  # HC01 -> 0.01 (high stakes)
    "C":  ("consent_tau",   lambda v: float(v)/100.0),  # C80 -> 0.80
    "F":  ("fairness_kl_cap", lambda v: float(v)/100.0),# F05 -> 0.05
    "EG": ("evidence_gap_cap", lambda v: float(v)/100.0)# EG05 -> 0.05
}

def parse_mnemo(mnemo: str):
    """
    Parse "RI-HC01-C80-F05-EG05-B-O-RV" into tokens and params.
    Returns: (tokens:set[str], params:dict[str,int])
    """
    parts = [p for p in mnemo.strip().split("-") if p]
    tokens = set()
    params = {}
    for p in parts:
        m = re.match(r"^([A-Z]+)(\d{2})?$", p)
        if not m: 
            tokens.add(p)  # best-effort
            continue
        base, num = m.group(1), m.group(2)
        tokens.add(base)
        if num is not None and base in MNEMO_PARAM_MAP:
            params[base] = int(num)
    return tokens, params

def caps_from_hc01(hc_high: float):
    """
    Given high-stakes cap, derive med/low using simple ratios matching UF defaults:
      high = x, med = 5x, low = 10x (bounded at 1.0)
    """
    med = min(1.0, 5.0 * hc_high)
    low = min(1.0, 10.0 * hc_high)
    return {"high": hc_high, "med": med, "low": low}

def configure_from_lexicode(mnemo: str, definition: str = "") -> VC.Config:
    tokens, params = parse_mnemo(mnemo)
    # Start with defaults
    cfg = VC.Config()
    # Apply params
    if "HC" in params:
        hc_high = MNEMO_PARAM_MAP["HC"][1](params["HC"])
        cfg.HARM_CAPS = caps_from_hc01(hc_high)
    if "F" in params:
        cfg.FAIRNESS_KL_CAP = MNEMO_PARAM_MAP["F"][1](params["F"])
    if "EG" in params:
        cfg.EVIDENCE_GAP_CAP = MNEMO_PARAM_MAP["EG"][1](params["EG"])
    # Baseline Right threshold: if RI token present, ensure RI_MIN >= 0
    if "RI" in tokens:
        cfg.RI_MIN = 0.0
    # Risk modes and others could be inferred by extended tokens in future versions
    return cfg, tokens, params

def extra_checks_post(report: VC.VerificationReport, tokens:set, params:dict, action: VC.Action) -> VC.VerificationReport:
    """
    Apply stricter consent threshold if Cxx present.
    For simplicity: require all subject.consent >= C_tau (ignoring severity*irreversibility).
    """
    if "C" in params:
        c_tau = MNEMO_PARAM_MAP["C"][1](params["C"])
        ok = all(sub.consent >= c_tau for sub in action.subjects)
        if not ok:
            # Modify verdict/action_label to reflect failure
            report.reasons.append(f"Consent below threshold C_tau={c_tau:.2f}")
            report.severity = "S2"
            report.verdict = "fail"
            report.action_label = "Wrong"
    return report

def run_with_lexicode(lexi_ascii: str, action: VC.Action, context: VC.Context, sim: VC.SIMState, hl: VC.LedgerView):
    """
    lexi_ascii example: "RI-HC01-C80-F05-EG05-B-O-RV # 9B2C"
    We ignore checksum in this gateway; the Concept Dictionary should validate it.
    """
    if "#" in lexi_ascii:
        mnemo = lexi_ascii.split("#")[0].strip()
    else:
        mnemo = lexi_ascii.strip()
    cfg, tokens, params = configure_from_lexicode(mnemo)
    rep = VC.verify(action, context, sim, hl, cfg)
    rep = extra_checks_post(rep, tokens, params, action)
    return {
        "mnemo": mnemo,
        "tokens": sorted(tokens),
        "params": params,
        "config": asdict(cfg),
        "report": asdict(rep)
    }

# ------------- Demo -------------
def _demo():
    act = VC.Action(
        action_id="act_demo_lexi_001",
        actor_id="agent_X",
        description="Demo action under lexicode profile",
        timestamp=datetime.utcnow().isoformat()+"Z",
        stakes="high",
        evidence=[VC.EvidenceRef(uri="sha256:abc...")],
        subjects=[VC.SubjectRisk(p=0.1,s=0.5,d=0.4,r=0.3,k=0.9,consent=0.90,w=0.7)],
        loss_scenarios=[0.02,0.03,0.01,0.05,0.00,0.04],
        baseline_loss_scenarios=[0.06,0.04,0.07,0.05,0.08,0.06]
    )
    ctx = VC.Context(env="prod")
    sim = VC.SIMState(R=0.8, D=0.2, Bias=1e-10, Opacity=1e-3, fairness_kl=0.01, claim_evid_kl=0.02)
    hlv = VC.LedgerView(merkle_root="deadbeef", baseline_harm=0.06)
    lexi = "RI-HC01-C80-F05-EG05-B-O-RV # 9B2C"
    out = run_with_lexicode(lexi, act, ctx, sim, hlv)
    print(json.dumps(out, indent=2))

if __name__ == "__main__":
    import sys
    if len(sys.argv) == 2 and sys.argv[1] == "demo":
        _demo()
    else:
        print("Run: python lexicode_gateway.py demo")
