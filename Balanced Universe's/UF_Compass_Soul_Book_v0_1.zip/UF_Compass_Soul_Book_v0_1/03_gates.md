# 3 • The Gates
**Harm (HC), Consent (C), Fairness (F), Honesty/Evidence Gap (EG), Bias (B), Opacity (O), Reversibility (RV).**  
We also honor **Agency (AG)** and **Causal Admissibility (CA)**.

**Rule:** Better than baseline is not enough—**caps must pass**.
