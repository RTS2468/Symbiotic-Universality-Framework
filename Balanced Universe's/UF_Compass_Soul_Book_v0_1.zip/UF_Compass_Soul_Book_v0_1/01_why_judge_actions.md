# 1 • Why Judge Actions, Not Beings
People are works-in-progress. UF keeps dignity by evaluating **what we do**, not labeling **who we are**. 
This mirrors a Christian conscience: conviction with compassion.
