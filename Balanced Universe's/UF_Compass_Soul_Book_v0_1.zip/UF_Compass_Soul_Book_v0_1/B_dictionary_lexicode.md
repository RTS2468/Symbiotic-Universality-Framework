# Appendix B • Concept Dictionary Seeds & Lexicode
- **Aligned-Limit Equivalence:** `RI-HC01-C80-F05-EG05-B-O-RV-PHI # 144748`  
- **Teleological Convergence:** `RI-HC01-C80-F05-EG05-B-O-RV-PHI # 86602E`

A=B rule: same mnemo+checksum ⇒ verdicts preserved.
