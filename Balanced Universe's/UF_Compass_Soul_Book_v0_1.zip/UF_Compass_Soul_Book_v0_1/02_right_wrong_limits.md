# 2 • Right (↑) / Wrong (↓); Good* / Evil (limits)
- **Right (↑):** RI ≥ 0 and all gates pass.
- **Wrong (↓):** RI < 0 or any gate fails.
- **Good\*:** limit as A → 1 (expected harm ≈ 0 and gates pass).
- **Evil:** collapse limit (persistent red-lines).

> Alignment map: \(A(u)=\frac{1}{1+e^{-u}}\). Right steps have \(\Delta u>0\).
