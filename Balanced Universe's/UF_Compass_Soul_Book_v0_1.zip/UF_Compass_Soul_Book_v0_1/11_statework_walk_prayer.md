# 11 • Statework: Sleep, Reflection, Walk, Prayer
Use time as an operator to clarify, reconcile, and act gently. 
End with one reversible step—better than baseline within caps.
