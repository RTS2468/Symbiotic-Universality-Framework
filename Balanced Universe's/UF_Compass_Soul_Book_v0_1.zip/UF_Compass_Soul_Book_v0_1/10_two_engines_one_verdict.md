# 10 • Two Engines, One Verdict (Head/Heart/Wisdom)
- **Head (I‑mode):** honesty, bias checks, clear reasons.
- **Heart (E‑mode):** consent, fairness, harm sensitivity.
- **Wisdom (W‑mode):** integrate; choose a small, reversible Right (↑) step.
