# Appendix C • Publishing Provenance
**AI‑assisted with UF gates.**  
List concept IDs / lexicode words used.  
Include a brief rationale (reasons), date, and reviewer line.
