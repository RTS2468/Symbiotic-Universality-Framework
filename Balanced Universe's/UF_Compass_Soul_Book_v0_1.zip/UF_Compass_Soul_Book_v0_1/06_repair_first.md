# 6 • Repair First (Reversibility)
Prefer actions we can **undo or repair**. When harm is possible, take the smallest step that still helps. 
Make restitution promptly; then take the next Right (↑) step.
