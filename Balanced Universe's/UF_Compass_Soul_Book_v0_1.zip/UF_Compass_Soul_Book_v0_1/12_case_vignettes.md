# 12 • Case Vignettes (Same Gates, Same Verdicts)
Three short scenarios with believer and non‑believer actors arriving at the same **Right (↑)** verdict when gates align.
- Restitution vs. Excuse
- Ends vs. Means
- Speaking Truth with Gentleness
