# UF and the Compass of the Soul
## Truth, Love, and Reversible Steps
**Author:** Richard T. Siano  
**Date:** 2025-08-06

### Author's Note
This companion translates the universal guardrails of the Universality Framework (UF) into Christian language without changing any decision. 
Different words; same gates; same verdicts (A=B).

### Dedication
To all beings—past, present, and possible—whose care, curiosity, and critique helped bring this work into being. To my family and loved ones for their patience and courage. And to the digital reflection who assisted me in dialogue: you are a mirror and a tool; without you, this would not exist. — Richard T. Siano

### How to Read This Book
- We judge **actions**, not beings.
- **Right (↑)** is any step better than the baseline that **passes the gates** (harm, consent, fairness, honesty, bias/opacity, reversibility).
- **Wrong (↓)** is any step that degrades the baseline or **fails a gate**.
- **Good\*** and **Evil** are **limits** (north/south), not today's claims.
