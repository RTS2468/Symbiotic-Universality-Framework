# Appendix A • Concordance (UF ↔ Scripture references)
Harm cap — Prov 3:27; Rom 12:17–18  
Consent/Agency — Gen 1:27; Mark 10:42–45; Gal 5:13  
Fairness — Lev 19:15; James 2:1–9  
Honesty/Opacity — Eph 4:25; 1 John 1:7; 1 Pet 3:15  
Reversibility/Repair — Matt 5:23–24; Acts 3:19  
Direction/Limit — John 3:19–21; Eph 5:8–11
