# 9 • Choice & Agency; R‑Markers
Belief and non‑belief are orientations; UF stays neutral and judges actions by the gates. 
Personal signs (R‑markers) may encourage but never alter evidence or caps.
