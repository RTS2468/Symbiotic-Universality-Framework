# 5 • Truthfulness & Reasons
Truthfulness means small **evidence gaps** and clear reasons (**opacity low**). 
“Speak the truth in love” keeps honesty and compassion yoked together.
