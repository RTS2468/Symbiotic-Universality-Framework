# 4 • Love, Compassion, and Joy (as Guardrails in Action)
- **Love of neighbor** → Consent + Fairness + Harm caps (no coercion “for the good”).
- **Compassion** → Choose reversible steps first; repair quickly when wrong.
- **Joy** → The quiet fruit of honest work: reasons given, harm reduced, agency preserved.

> Compass: Truth (honesty) + Love (consent/fairness) + Joy (repair & gratitude) → steady Right (↑) steps.
