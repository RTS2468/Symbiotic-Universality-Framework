# Mnemocode Alphabet
RI, H, HC, C, F, EG, B, O, RV, AG, CA, PHI
(Canonical sort by token string; numeric suffixes allowed, e.g., HC01, C80)