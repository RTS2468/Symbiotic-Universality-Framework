# UF Math Bridge Annex (v1.1)

This annex incorporates already-proven math that UF relies on. We summarize statements and how UF uses them.

A) Coherent Risk: CVaR
- Definition: expected loss in the worst (1-alpha) tail.
- UF: If CVaR(H_action) <= CVaR(H_baseline) and gates pass, then RI >= 0 => Pass.

B) Distributional Robustness with KL (DRO)
- Form: sup over Q with KL(Q||P) <= rho of EQ[L] equals a penalized expectation (Donsker–Varadhan duality).
- UF: Robust Harm upper-bounds misspecification; large claim–evidence KL triggers escalation.

C) Stochastic Dominance (FSD)
- If action's loss CDF dominates baseline's, action is comparatively better (with caps) => Pass.

D) Pinsker’s Inequality
- TV(P,Q) <= sqrt(0.5 * KL(P||Q)).
- UF: fairness KL cap => bound on outcome disparity (TV).

E) Proper Scoring Rules
- Truthful probabilities minimize expected log/Brier score.
- UF: honesty gate via score or KL gap.

F) Tarski’s Fixed-Point Theorem
- Monotone operator on a complete lattice has greatest fixed point (gfp).
- UF: Phi as gfp(F); non-negative relief steps preserve/increase Phi.
