# UF Concept Dictionary Kit (v1.0)

Date: 2025-08-06

This kit lets you create precise, universal concept entries for the Universality Framework (UF).
IDs follow: `<Alias> :: <Mnemocode> # <Checksum>` where the checksum is the first 6 hex
characters of SHA-256 of the `definition` text.

Contents:
- concept_entry.schema.json
- concept_tool.py
- mnemo_alphabet.md
- seed/ (starter YAML entries)
- UF_Math_Bridge_Annex_v1.1.md
