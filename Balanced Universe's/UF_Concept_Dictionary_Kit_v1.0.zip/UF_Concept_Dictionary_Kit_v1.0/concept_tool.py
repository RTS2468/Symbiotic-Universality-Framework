#!/usr/bin/env python3
import sys, json, yaml, hashlib, re
from pathlib import Path

ALLOWED_TOKENS = ["RI","H","HC","C","F","EG","B","O","RV","AG","CA","PHI"]

TEMPLATE = {
  "id": {"alias": "AliasHere", "mnemo": "RI-HC-C-F-EG-B-O-RV", "checksum": ""},
  "definition": "One to five precise sentences that define the concept.",
  "uf_mapping": {
    "equations": ["RI = max(H(b) - H(a), 0)/max(H(b), eps)"],
    "gates": ["HC(stakes)", "Consent", "Fairness", "EvidenceGap", "Bias", "Opacity", "Reversibility"]
  },
  "inputs": ["action","baseline","evidence","stakes"],
  "outputs": ["verdict","metrics"],
  "caps": ["HC<=ctx_cap","Bias<=cap","Opacity<=cap","KL_claim_evid<=cap","Fairness<=cap"],
  "invariants_preserved": ["I1","I2","I3","I4","I5","I6","I7"],
  "examples": ["Minimal example text."],
  "status": "draft",
  "version": "1.0"
}

def canonicalize_mnemo(mn):
    parts = mn.split("-")
    def key(p):
        m = re.match(r"^([A-Z]+)([0-9]+)?$", p)
        if not m: raise ValueError(f"Bad token: {p}")
        base = m.group(1); num = int(m.group(2)) if m.group(2) else -1
        if base not in ALLOWED_TOKENS: raise ValueError(f"Unknown token: {base}")
        return (base, num)
    return "-".join(sorted(parts, key=key))

def checksum_from_definition(def_text, n=6):
    return hashlib.sha256(def_text.strip().encode("utf-8")).hexdigest()[:n].upper()

def load_entry(path):
    text = Path(path).read_text(encoding="utf-8")
    if str(path).lower().endswith((".yaml",".yml")):
        return yaml.safe_load(text)
    return json.loads(text)

def save_entry(path, obj):
    p = Path(path)
    if str(p).lower().endswith((".yaml",".yml")):
        p.write_text(yaml.safe_dump(obj, sort_keys=False), encoding="utf-8")
    else:
        p.write_text(json.dumps(obj, indent=2), encoding="utf-8")

def cmd_new(path):
    save_entry(path, TEMPLATE); print(f"Template written to {path}")

def cmd_checksum(path):
    obj = load_entry(path)
    obj["id"]["mnemo"] = canonicalize_mnemo(obj["id"]["mnemo"])
    obj["id"]["checksum"] = checksum_from_definition(obj["definition"])
    save_entry(path, obj)
    print(f"Checksum updated: {obj['id']['checksum']} for {path}")

def cmd_validate(path, schema_path="concept_entry.schema.json"):
    try:
        import jsonschema
    except Exception:
        jsonschema = None
        print("Install jsonschema for full validation (`pip install jsonschema`).")
    obj = load_entry(path)
    obj["id"]["mnemo"] = canonicalize_mnemo(obj["id"]["mnemo"])
    calc = checksum_from_definition(obj["definition"])
    if obj["id"]["checksum"] != calc:
        print(f"WARNING: checksum mismatch (entry={obj['id']['checksum']} vs calc={calc}).")
    if jsonschema:
        schema = json.loads(Path(schema_path).read_text(encoding="utf-8"))
        jsonschema.validate(obj, schema); print("Schema validation: OK")
    print("Mnemonic (canonical):", obj["id"]["mnemo"])
    print("Alias:", obj["id"]["alias"])
    print("Checksum:", obj["id"]["checksum"] or calc)

def main():
    if len(sys.argv) < 2:
        print("Usage: concept_tool.py new <file.yaml> | checksum <file.yaml> | validate <file.yaml> [schema.json]"); return
    cmd = sys.argv[1]
    if cmd == "new" and len(sys.argv) == 3: cmd_new(sys.argv[2])
    elif cmd == "checksum" and len(sys.argv) == 3: cmd_checksum(sys.argv[2])
    elif cmd == "validate":
        schema = sys.argv[3] if len(sys.argv) >= 4 else "concept_entry.schema.json"
        cmd_validate(sys.argv[2], schema)
    else:
        print("Usage: concept_tool.py new <file.yaml> | checksum <file.yaml> | validate <file.yaml> [schema.json]")

if __name__ == "__main__":
    main()
