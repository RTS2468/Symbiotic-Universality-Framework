# Universality Framework — Middle School Textbook (v0.1 Alpha)

**Date:** 2025-08-06  
**Audience:** Middle School (Grades 6–8)  
**Tone/Style:** Conversational, activity-driven  
**License:** CC BY-NC-ND 4.0

---
## Dedication
To Xylie, Taric, and Lumina Siano—thank you for inspiring a framework that helps us make kind, fair, and thoughtful choices every day.

---
## Preface
This textbook introduces the Universality Framework (UF) at a middle school level. You’ll learn how we describe **choices**, **consequences**, and **fairness** using simple math and clear steps. Pictures and activities help connect ideas to real life.

---
## Table of Contents

1. Systems & Feedback (The Alignment Loop)
2. Evidence & Honesty (HL Basics)
3. Purpose Vector & Bounded Passion
4. Harm, Consent, and Due Care
5. Bias, Opacity, and Ethical Compliance
6. Virtues & Sins as Action Indices
7. Pain, Suffering, Pleasure, Joy
8. Theoretical Affect Space
9. Case Studies: School & Community
10. Project: Design a Fair Process
11. Debate: Thresholds and Trade-offs
12. Capstone Reflection

---
## Figures (starter pack)
- Figure 1. Alignment Loop — Sense → Compare → Nudge → Commit. (figures/alignment_loop.png)
- Figure 2. Holographic Ledger fields overview. (figures/holographic_ledger_fields.png)
- Figure 3. Purpose Vector triangle. (figures/purpose_vector_triangle.png)
- Figure 4. Ethical Compliance equation. (figures/ethical_compliance.png)
- Figure 5. Theoretical Affect Space axes. (figures/affect_space_axes.png)
- Figure 6. Virtues & Sins wheel. (figures/virtues_sins_wheel.png)

---
## Chapter Samples

### Chapter 1: What Is a Choice?
**Story/Hook:** A short scenario tailored to middle school learners.  
**Idea:** Every choice changes our world a tiny bit. We can log choices to learn and improve.  
**Figure:** Alignment Loop (Figure 1).

**Activity (Engage → Explore → Explain → Extend → Evaluate):**
- Engage: Think-pair-share about a simple decision.
- Explore: Try a role-play with two options.
- Explain: Draw the loop and label each step.
- Extend: Add one more check you would do before committing.
- Evaluate: Journal: Which step helps you most?

### Chapter 2: Fairness and Respect
**Idea:** Fairness means trying to treat outcomes like a fair wheel.  
**Math Peek:** We compare what happened with what would be fair.
**Figure:** Holographic Ledger fields (Figure 2).

### Chapter 3: Purpose and Passion
**Idea:** Our purposes can be balanced between **self-betterment**, **doing right**, and **helping others**. Passion makes us unique, but stays bounded.  
**Figure:** Purpose Vector triangle (Figure 3).

### Chapter 4: Doing No Harm
**Idea:** We measure harm with simple parts: chance, severity, time, reversibility, care, and consent.  
**Figure:** Ethical Compliance (Figure 4).

### Chapter 5: Feelings and Choices
**Idea:** Feelings fit inside a simple “compass” so we can talk about them.  
**Figure:** Theoretical Affect Space (Figure 5).

### Chapter 6: Virtues & Sins (Actions Only)
**Idea:** We don’t label people—we look at actions. Virtues and sins help us reflect.  
**Figure:** Virtues & Sins wheel (Figure 6).

---
## Assessments
- Quick checks, projects, and reflections matched to each chapter.

## Glossary
- Choice, Context, Faith, Resonance (R), Dissonance (D), Alignment (A), Harm, Relief, Purpose, Passion.

## Change Log
- v0.1 Alpha — initial skeleton, figures, and sample chapters.
